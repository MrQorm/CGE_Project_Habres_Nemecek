#ifndef PLANET_H
#define PLANET_H
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
void planet(float a, float b , float c, float x ,int k , int l, int u);

void earth(int y,int x, GLuint gl);
#endif // PLANET_H
# CGE_Project_Habres_Nemecek

Demo Application Solar System

Controls:
UP-Key:   increase simulation speed
DOWN-Key: decrease simulation speed

W:        Move Forward

S:        Move Backward

A:        Move Left

D:        Move Right


I:        Tilt Camera Up

K:        Tilt Camera Down

J:        Tilt Camera Left

L:        Tilt Camera Right
